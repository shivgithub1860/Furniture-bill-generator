
console.log("Furniture Measurement Bill Generator Loaded");
